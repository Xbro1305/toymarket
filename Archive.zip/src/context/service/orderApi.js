// import { api } from "./api";

// export const orderApi = api.injectEndpoints({
//   endpoints: (builder) => ({
//     getQrCode: builder.query({
//       query: (code) => `/img/qrcode/${code}`,
//       providesTags: ["QrCode"],
//     }),
//   }),
// });

// export const { useGetQrCodeQuery } = orderApi;
